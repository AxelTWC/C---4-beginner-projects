﻿﻿/* Simple Exercise: Different outputs
 Name: Axel Tang
 Date: Febuary 3
 Teacher: Mrs.Schilstra
 Purpose: Trying out different outputs
*/

using System;

namespace Different_Output_Exercise
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("OutPut #1"); //Writes Out "Output #1"
            Console.WriteLine("Our life is like, a thorny rose. Not perfect, but always beautiful."); //Writes out the quote in a single line
            Console.WriteLine("\n");
            Console.WriteLine("OutPut #2"); //Writes Out "Output #2"
            Console.WriteLine("Our life is like,\nA thorny rose.\nNot perfect,\nBut always beautiful."); //Writes out the quote in sections with one line of code
            Console.WriteLine("\n");
            Console.WriteLine("OutPut #3"); //Writes Out "Output #3"
            Console.WriteLine("\tOur\n\tlife\n\tis\n\tlike,\n\tA\n\tthorny\n\trose.\n\tNot\n\tperfect,\n\tBut\n\talways\n\tbeautiful."); //Writes out the quote by every single word with one line of code 
            Console.ReadLine();
        }
    }
}