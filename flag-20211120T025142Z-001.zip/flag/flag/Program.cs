﻿﻿/* Simple Exercise: Creating a Flag
  Name: Axel Tang
  Date: Febuary 3
  Teacher: Mrs.Schilstra
  Purpose: Creating a Flag with Code
*/

using System;

namespace Flag
{
    class Program
    {
        static void Main(string[] args)
        {
            //Only Use "M" for Maple Leaf 
            //Only Use "-" & "|" for the border
            //Only Use "X" for the sides


            Console.WriteLine("---------------------------------------------------------------------"); //All Console.WriteLine will write out the strings
            Console.WriteLine("|XXXXXXXXXXXXXXXX                                   XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX                 M                 XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX                MMM                XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX           MM  MMMMM  MM           XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX            MMMMMMMMMMM            XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX        MM   MMMMMMMMM   MM        XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX    MMMMMMMM  MMMMMMM  MMMMMMMM    XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX     MMMMMMMMMMMMMMMMMMMMMMMMM     XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX   MMMMMMMMMMMMMMMMMMMMMMMMMMMMM   XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX      MMMMMMMMMMMMMMMMMMMMMMM      XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX         MMMMMMMMMMMMMMMMM         XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX           MMMMMMMMMMMMM           XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX          MMMMMMMMMMMMMMM          XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX       MMM       M       MMM       XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX                 M                 XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX                 M                 XXXXXXXXXXXXXXXX|");
            Console.WriteLine("|XXXXXXXXXXXXXXXX                                   XXXXXXXXXXXXXXXX|");
            Console.WriteLine("---------------------------------------------------------------------");
            Console.ReadLine();
        }
    }
}