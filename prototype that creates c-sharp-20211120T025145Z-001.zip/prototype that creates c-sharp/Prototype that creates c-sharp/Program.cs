﻿﻿/* Simple Exercise: Creating a prototype
  Name: Axel Tang
  Date: Febuary 3
  Teacher: Mrs.Schilstra
  Purpose: Creating a prototpye with code
*/

using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("XXXXXXXXXXXXXXX"); //Writes out the first line
            Console.WriteLine("XXXXXXXXXXXXXXX"); //Writes out the second line
            Console.WriteLine("XXXX \t\t\t##\t##"); // writes out the thrid line
            Console.WriteLine("XXXX \t\t      ##############"); //Writes out the fourth line
            Console.WriteLine("XXXX \t\t\t##\t##"); //Writes out the fifth line
            Console.WriteLine("XXXX \t\t\t##\t##"); //Writes out the sixth line
            Console.WriteLine("XXXX \t\t      ##############"); //Writes out the seventh line
            Console.WriteLine("XXXX \t\t\t##\t##"); //Writes out the eighth line
            Console.WriteLine("XXXXXXXXXXXXXXX"); //Writes out the ninth line
            Console.WriteLine("XXXXXXXXXXXXXXX"); //Writes out the tenth line
            Console.ReadLine();
        }
    }
}