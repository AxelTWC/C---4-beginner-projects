﻿/* decisionDecision Program 
   Name: Axel Tang
   Date: February 12
   Teacher: Mrs.Schilstra
   Purpose: Creating a decision program and to print out tickets
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int cost = 0; //Variable for total ticket cost, starting value being at 0 
            int Ticket1 = 0; //Variable for the number of Children's Tickets
            int Ticket2 = 0; //Variable for the number of Teenager's Tickets
            int Ticket3 = 0; //Variable for the number of Adult's Tickets
            int Ticket4 = 0; //Variable for the number of Senior's Tickets
            int Ticket5 = 0; //Variable for the number of Elder's Tickets

            /*
             All int commands are used to declare a variable 
             All Console.ForegroundColor & Console.BackgroundColor are to set colors 
             All Console.WriteLine() are to print out the text
             All Console.ReadLine() are to pause the console until the user press enter key
             */

            for (int i = 1; i < 99; i++) //Loops the program
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█");
                Console.WriteLine("█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█");
                Console.WriteLine("█░░║║║╠─║─║─║║║║║╠─░░█");
                Console.WriteLine("█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█");
                Console.WriteLine("█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█");


                //Welcoming to the program and asking for names for tickets 

            start: //Starting point only for users who accidentally typed in a negative value
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("\n");
                Console.WriteLine("\n");
                Console.WriteLine("Welcome to the ticket store!\nplease type your name!");
                Console.ForegroundColor = ConsoleColor.White;
                string name;
                name = Console.ReadLine(); //Assign the name to the string

                //Asking for gender


                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Please state your gender");
                Console.ForegroundColor = ConsoleColor.White;
                string gender;
                gender = Console.ReadLine(); //Assign a gender to the string

                //Asking for age


                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Please state your age");
                Console.ForegroundColor = ConsoleColor.White;
                int age;
                age = int.Parse(Console.ReadLine()); //Assign a value to age


                Console.BackgroundColor = ConsoleColor.Cyan;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("Press Enter to print out your ticket");
                Console.WriteLine("\n");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;

                //Decision Maker for Prices with the age given by the user
                /* All cost = cost + "number" are for summing up the total price of all tickets
                   All Ticket"1-5" + 1 are for adding up the total number of that specific ticket
                 */

                if (age < 0) //For people who input a negative age value
                {

                    Console.WriteLine("Get Born");
                    Console.WriteLine("Invalid input, please try again!");
                    Console.ReadLine();
                    goto start;

                }


                else if (age == 0 || age <= 12) //For people who are in the range of 0 to 12 years old
                {

                    Console.WriteLine("Your ticket cost $5");
                    Console.ReadLine();
                    cost = cost + 5;
                    Ticket1 = Ticket1 + 1;

                }

                else if (age == 13 || age <= 17) //For people who are in the range of 13 to 17 years old
                {
                    Console.WriteLine("Your ticket cost $12");
                    Console.ReadLine();
                    cost = cost + 12;
                    Ticket2 = Ticket2 + 1;
                }

                else if (age == 18 || age <= 64) //For people who are in the range of 18 to 64 years old
                {
                    Console.WriteLine("Your ticket cost $15");
                    Console.ReadLine();
                    cost = cost + 15;
                    Ticket3 = Ticket3 + 1;


                }

                else if (age == 65 || age <= 99) //For people who are in the range of 65 to 99 years old
                {
                    Console.WriteLine("Your ticket cost $10");
                    Console.ReadLine();
                    cost = cost + 10;
                    Ticket4 = Ticket4 + 1;

                }


                else if (age > 99) //For people who are above 99 years old
                {
                    Console.WriteLine("Your ticket is free");
                    Console.ReadLine();
                    Ticket5 = Ticket5 + 1;
                }

                //Displaying the ticket

                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("  __| |_______________________________________| |__");
                Console.WriteLine("(__   _______________________________________   __)");
                Console.WriteLine("\n");
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("\t\t      Ticket");
                Console.WriteLine("\n");
                Console.WriteLine("\t\t     Name:" + name.ToString());
                Console.WriteLine("\t\t     Gender:" + gender.ToString());
                Console.WriteLine("\t\t     Age:" + age);
                Console.WriteLine("\n");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("(__   _______________________________________   __)");
                Console.WriteLine("    | |                                       | |");
                Console.WriteLine("\n");
                Console.WriteLine("\n");

                //Ticket ends here and will asking if the user wants to buy again

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Do you want to stop buying tickets?");
                Console.WriteLine("\n");
                Console.WriteLine("Press 1 to end");
                Console.WriteLine("Else, press any number to continue");

                //Code to check if the user still wants to continue buying or not
                int answer;
                answer = int.Parse(Console.ReadLine());

                if (answer == 1) //If user types in 1, the decision making and ticket printing program will stop and will show the receipt, if not the program goes from the start again and starts looping
                {
                    Console.WriteLine("Thank you for buying!");
                    Console.WriteLine("\n");
                    Console.WriteLine("\tReceipt:");
                    Console.WriteLine("\n");
                    Console.WriteLine("Children Tickets:\t" + Ticket1);
                    Console.WriteLine("Teenager Tickets:\t" + Ticket2);
                    Console.WriteLine("Adult    Tickets:\t" + Ticket3);
                    Console.WriteLine("Senior   Tickets:\t" + Ticket4);
                    Console.WriteLine("Elders   Tickets:\t" + Ticket5);
                    int Total = Ticket1 + Ticket2 + Ticket3 + Ticket4 + Ticket5; 
                    Console.WriteLine("\n");
                    Console.WriteLine("Total Tickets Bought:\t" + Total);
                    Console.WriteLine("\n");
                    Console.WriteLine("The total cost:$" + cost);
                    Console.WriteLine("Please pay by https://www.paypal.me/AxelTWC");
                    Console.WriteLine("Have a nice day!");
                    Console.ReadLine();
                    break;
                }


            }



        }
    }
}




